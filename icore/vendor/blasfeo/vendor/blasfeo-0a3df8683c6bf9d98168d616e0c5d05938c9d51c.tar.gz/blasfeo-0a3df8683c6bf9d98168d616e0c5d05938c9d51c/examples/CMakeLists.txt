###################################################################################################
#                                                                                                 #
# This file is part of BLASFEO.                                                                   #
#                                                                                                 #
# BLASFEO -- BLAS For Embedded Optimization.                                                      #
# Copyright (C) 2019 by Gianluca Frison.                                                          #
# Developed at IMTEK (University of Freiburg) under the supervision of Moritz Diehl.              #
# All rights reserved.                                                                            #
#                                                                                                 #
# The 2-Clause BSD License                                                                        #
#                                                                                                 #
# Redistribution and use in source and binary forms, with or without                              #
# modification, are permitted provided that the following conditions are met:                     #
#                                                                                                 #
# 1. Redistributions of source code must retain the above copyright notice, this                  #
#    list of conditions and the following disclaimer.                                             #
# 2. Redistributions in binary form must reproduce the above copyright notice,                    #
#    this list of conditions and the following disclaimer in the documentation                    #
#    and/or other materials provided with the distribution.                                       #
#                                                                                                 #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND                 #
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED                   #
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE                          #
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR                 #
# ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES                  #
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;                    #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND                     #
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT                      #
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS                   #
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.                                    #
#                                                                                                 #
# Author: Gianluca Frison, gianluca.frison (at) imtek.uni-freiburg.de                             #
#                                                                                                 #
###################################################################################################


if(${DP_ROUTINES})
	add_executable(getting_started getting_started.c)
	add_executable(example_d_lu_factorization example_d_lu_factorization.c)
	add_executable(example_d_lq_factorization example_d_lq_factorization.c)
	add_executable(example_d_riccati_recursion example_d_riccati_recursion.c tools.c)
endif()
if(${SP_ROUTINES})
	add_executable(example_s_lu_factorization example_s_lu_factorization.c)
	add_executable(example_s_riccati_recursion example_s_riccati_recursion.c tools.c)
endif()

if(CMAKE_C_COMPILER_ID MATCHES MSVC) # no explicit math library and no running blas api (for now)

	if(${DP_ROUTINES})
		target_link_libraries(getting_started blasfeo)
		target_link_libraries(example_d_lu_factorization blasfeo)
		target_link_libraries(example_d_lq_factorization blasfeo)
		target_link_libraries(example_d_riccati_recursion blasfeo)
	endif()
	if(${SP_ROUTINES})
		target_link_libraries(example_s_lu_factorization blasfeo)
		target_link_libraries(example_s_riccati_recursion blasfeo)
	endif()

else() # add explicit math library

	if(${DP_ROUTINES})
		target_link_libraries(getting_started blasfeo ${EXTERNAL_BLAS_LIBRARIES} m)
		target_link_libraries(example_d_lu_factorization blasfeo ${EXTERNAL_BLAS_LIBRARIES} m)
		target_link_libraries(example_d_lq_factorization blasfeo ${EXTERNAL_BLAS_LIBRARIES} m)
		target_link_libraries(example_d_riccati_recursion blasfeo ${EXTERNAL_BLAS_LIBRARIES} m)
	endif()
	if(${SP_ROUTINES})
		target_link_libraries(example_s_lu_factorization blasfeo ${EXTERNAL_BLAS_LIBRARIES} m)
		target_link_libraries(example_s_riccati_recursion blasfeo ${EXTERNAL_BLAS_LIBRARIES} m)
	endif()

endif()

