/**
 * @file cone.c
 * @author Govind M. Chari <govindchari1@gmail.com>
 *
 * @section LICENSE
 *
 * Copyright (c) 2024, Govind M. Chari
 * This source code is licensed under the BSD 3-Clause License
 */

#include "cone.h"

#define CUDA_CHECK(call)                                                       \
  do {                                                                         \
    cudaError_t err = call;                                                    \
    if (err != cudaSuccess) {                                                  \
      fprintf(stderr, "CUDA error at %s:%d: %s\n", __FILE__, __LINE__,         \
              cudaGetErrorString(err));                                        \
      exit(1);                                                                 \
    }                                                                          \
  } while (0)

__device__ __forceinline__ QOCOFloat qoco_max_dev(QOCOFloat a, QOCOFloat b)
{
  return a > b ? a : b;
}

__device__ QOCOFloat soc_residual(const QOCOFloat* u, QOCOInt n)
{
  QOCOFloat sum = 0.0;
  for (QOCOInt i = 1; i < n; ++i) {
    sum += u[i] * u[i];
  }
  return sqrt(sum) - u[0];
}

__device__ QOCOFloat soc_residual2(const QOCOFloat* u, QOCOInt n)
{
  QOCOFloat res = u[0] * u[0];
  for (QOCOInt i = 1; i < n; ++i) {
    res -= u[i] * u[i];
  }
  return res;
}

__device__ void scale_arrayf_dev(const QOCOFloat* x, QOCOFloat* y, QOCOFloat s,
                                 QOCOInt n)
{
  for (QOCOInt i = 0; i < n; ++i) {
    y[i] = s * x[i];
  }
}

__device__ QOCOFloat qoco_dot_dev(const QOCOFloat* u, const QOCOFloat* v,
                                  QOCOInt n)
{
  QOCOFloat x = 0.0;
  for (QOCOInt i = 0; i < n; ++i) {
    x += u[i] * v[i];
  }
  return x;
}

__device__ void soc_product(const QOCOFloat* u, const QOCOFloat* v,
                            QOCOFloat* p, QOCOInt n)
{
  p[0] = qoco_dot_dev(u, v, n);
  for (QOCOInt i = 1; i < n; ++i) {
    p[i] = u[0] * v[i] + v[0] * u[i];
  }
}

__device__ void soc_division(const QOCOFloat* lam, const QOCOFloat* v,
                             QOCOFloat* d, QOCOInt n)
{
  QOCOFloat f = lam[0] * lam[0] - qoco_dot_dev(&lam[1], &lam[1], n - 1);
  QOCOFloat finv = safe_div(1.0, f);
  QOCOFloat lam0inv = safe_div(1.0, lam[0]);
  QOCOFloat lam1dv1 = qoco_dot_dev(&lam[1], &v[1], n - 1);

  d[0] = finv * (lam[0] * v[0] - qoco_dot_dev(&lam[1], &v[1], n - 1));
  for (QOCOInt i = 1; i < n; ++i) {
    d[i] = finv *
           (-lam[i] * v[0] + lam0inv * f * v[i] + lam0inv * lam1dv1 * lam[i]);
  }
}

__global__ void set_Wfull_linear(QOCOFloat* W, QOCOInt Wnnzfull, QOCOInt l)
{
  QOCOInt i = blockIdx.x * blockDim.x + threadIdx.x;

  if (i < Wnnzfull) {
    W[i] = 0.0;
  }
  if (i < l) {
    W[i] = 1.0;
  }
}

__global__ void set_Wfull_soc(QOCOFloat* W, QOCOInt* q, QOCOInt* Wsoc_idx,
                              QOCOInt nsoc, QOCOInt l)
{
  QOCOInt soc = blockIdx.x;
  if (soc >= nsoc)
    return;

  QOCOInt dim = q[soc];
  QOCOInt k = threadIdx.x;

  if (k >= dim)
    return;

  // diagonal element
  W[Wsoc_idx[soc] + k * dim + k] = 1.0;
}

__global__ void cone_residual_stage1(const QOCOFloat* u, QOCOInt l,
                                     QOCOInt nsoc, const QOCOInt* q,
                                     QOCOInt* soc_idx, QOCOFloat* block_out)
{
  extern __shared__ QOCOFloat sdata[];

  QOCOInt tid = threadIdx.x;
  QOCOInt gid = blockIdx.x * blockDim.x + tid;

  QOCOFloat val = -1e7;

  if (gid < l) {
    // LP cone
    val = -u[gid];
  }
  else if (gid < l + nsoc) {
    // SOC cone: one thread per SOC
    QOCOInt soc = gid - l;
    val = soc_residual(&u[soc_idx[soc]], q[soc]);
  }

  sdata[tid] = val;
  __syncthreads();

  // block-level max reduction
  for (QOCOInt stride = blockDim.x / 2; stride > 0; stride >>= 1) {
    if (tid < stride) {
      sdata[tid] = qoco_max_dev(sdata[tid], sdata[tid + stride]);
    }
    __syncthreads();
  }

  if (tid == 0) {
    block_out[blockIdx.x] = sdata[0];
  }
}

__global__ void cone_residual_stage2(const QOCOFloat* in, QOCOFloat* out,
                                     QOCOInt n)
{
  extern __shared__ QOCOFloat sdata[];

  QOCOInt tid = threadIdx.x;
  QOCOInt gid = tid;

  QOCOFloat val = -1e7;
  if (gid < n)
    val = in[gid];

  sdata[tid] = val;
  __syncthreads();

  for (QOCOInt stride = blockDim.x / 2; stride > 0; stride >>= 1) {
    if (tid < stride) {
      sdata[tid] = qoco_max_dev(sdata[tid], sdata[tid + stride]);
    }
    __syncthreads();
  }

  if (tid == 0)
    *out = sdata[0];
}

__global__ void bring2cone_kernel(QOCOFloat* u, QOCOInt* q, QOCOInt l,
                                  QOCOInt nsoc)
{
  // Single-thread kernel
  if (threadIdx.x != 0 || blockIdx.x != 0)
    return;

  QOCOFloat a = 0.0;
  QOCOInt idx = 0;

  /* ---------- LP cone ---------- */
  for (idx = 0; idx < l; ++idx) {
    a = qoco_max(a, -u[idx]);
  }
  a = qoco_max(a, (QOCOFloat)0.0);

  /* ---------- SOC cones ---------- */
  for (QOCOInt i = 0; i < nsoc; ++i) {
    QOCOInt qi = q[i];
    QOCOFloat soc_res = soc_residual(&u[idx], qi);
    if (soc_res > a) {
      a = soc_res;
    }
    idx += qi;
  }

  QOCOFloat shift = (QOCOFloat)(1.0) + a;

  /* ---------- Update LP cone ---------- */
  for (idx = 0; idx < l; ++idx) {
    u[idx] += shift;
  }

  /* ---------- Update SOC cones ---------- */
  for (QOCOInt i = 0; i < nsoc; ++i) {
    u[idx] += shift;
    idx += q[i];
  }
}

__global__ void compute_nt_scaling_kernel(QOCOFloat* W, QOCOFloat* WtW,
                                          QOCOFloat* Wfull, QOCOFloat* Winv,
                                          QOCOFloat* Winvfull, QOCOFloat* s,
                                          QOCOFloat* z, QOCOFloat* sbar,
                                          QOCOFloat* zbar, QOCOInt l,
                                          QOCOInt nsoc, const QOCOInt* q)
{
  QOCOInt tid = blockIdx.x * blockDim.x + threadIdx.x;

  /* ================= LP cone ================= */
  if (tid < l) {
    QOCOFloat val = safe_div(s[tid], z[tid]);
    WtW[tid] = val;
    QOCOFloat w = qoco_sqrt(val);

    W[tid] = w;
    Wfull[tid] = w;

    QOCOFloat winv = safe_div((QOCOFloat)1.0, w);
    Winv[tid] = winv;
    Winvfull[tid] = winv;
    return;
  }

  /* ================= SOC cones ================= */
  QOCOInt soc_id = tid - l;
  if (soc_id >= nsoc)
    return;

  /* ---- compute SOC offsets ---- */
  QOCOInt idx = l;
  QOCOInt nt_idx = l;
  QOCOInt nt_idx_full = l;

  for (QOCOInt k = 0; k < soc_id; ++k) {
    idx += q[k];
    nt_idx += (q[k] * q[k] + q[k]) / 2;
    nt_idx_full += q[k] * q[k];
  }

  QOCOInt qi = q[soc_id];

  /* --- normalize s --- */
  QOCOFloat s_scal = qoco_sqrt(soc_residual2(&s[idx], qi));
  QOCOFloat f = safe_div((QOCOFloat)1.0, s_scal);
  scale_arrayf_dev(&s[idx], &sbar[idx], f, qi);

  /* --- normalize z --- */
  QOCOFloat z_scal = qoco_sqrt(soc_residual2(&z[idx], qi));
  f = safe_div((QOCOFloat)1.0, z_scal);
  scale_arrayf_dev(&z[idx], &zbar[idx], f, qi);

  QOCOFloat gamma =
      qoco_sqrt((QOCOFloat)0.5 *
                ((QOCOFloat)1.0 + qoco_dot_dev(&sbar[idx], &zbar[idx], qi)));

  // For some unknown reason, when I replace the line below with
  // safe_div(1.0, 2.0 * gamma), when gamma=1.001301, we expect f=0.499350,
  // but we get f=0.500650, so safe_div is not used here. When safe_div is
  // used, all SOCP unit tests fail. Likely some GPU weirdness.
  f = 1.0 / (2.0 * gamma);

  /* overwrite sbar with wbar */
  sbar[idx + 0] = f * (sbar[idx + 0] + zbar[idx + 0]);
  for (QOCOInt j = 1; j < qi; ++j)
    sbar[idx + j] = f * (sbar[idx + j] - zbar[idx + j]);

  /* overwrite zbar with v */
  f = safe_div((QOCOFloat)1.0,
               qoco_sqrt((QOCOFloat)2.0 * (sbar[idx + 0] + (QOCOFloat)1.0)));

  zbar[idx + 0] = f * (sbar[idx + 0] + (QOCOFloat)1.0);
  for (QOCOInt j = 1; j < qi; ++j)
    zbar[idx + j] = f * sbar[idx + j];

  /* --- build W and Winv --- */
  QOCOFloat fwd = qoco_sqrt(safe_div(s_scal, z_scal));
  QOCOFloat finv = 1.0 / fwd;

  QOCOInt shift = 0;
  for (QOCOInt j = 0; j < qi; ++j) {
    for (QOCOInt k = 0; k <= j; ++k) {

      QOCOFloat val = (QOCOFloat)2.0 * zbar[idx + k] * zbar[idx + j];
      QOCOFloat winv_val = val;

      if (j != 0 && k == 0)
        winv_val = -val;

      if (j == 0 && k == 0) {
        val -= (QOCOFloat)1.0;
        winv_val -= (QOCOFloat)1.0;
      }
      else if (j == k) {
        val += (QOCOFloat)1.0;
        winv_val += (QOCOFloat)1.0;
      }

      val *= fwd;
      winv_val *= finv;

      QOCOInt full1 = nt_idx_full + j * qi + k;
      QOCOInt full2 = nt_idx_full + k * qi + j;

      W[nt_idx + shift] = val;
      Winv[nt_idx + shift] = winv_val;

      Wfull[full1] = val;
      Wfull[full2] = val;
      Winvfull[full1] = winv_val;
      Winvfull[full2] = winv_val;

      shift++;
    }
  }

  /* --- compute WtW --- */
  shift = 0;
  for (QOCOInt j = 0; j < qi; ++j) {
    for (QOCOInt k = 0; k <= j; ++k) {
      WtW[nt_idx + shift] = qoco_dot_dev(&Wfull[nt_idx_full + j * qi],
                                         &Wfull[nt_idx_full + k * qi], qi);
      shift++;
    }
  }
}

__global__ void nt_multiply_kernel(const QOCOFloat* W, const QOCOInt* Wsoc_idx,
                                   const QOCOInt* soc_idx, const QOCOFloat* x,
                                   QOCOFloat* z, QOCOInt l, QOCOInt m,
                                   QOCOInt nsoc, const QOCOInt* q)
{
  QOCOInt i = blockIdx.x * blockDim.x + threadIdx.x;
  if (i >= l + nsoc)
    return;

  /* ================= LP cone ================= */
  if (i < l) {
    z[i] = W[i] * x[i];
    return;
  }

  /* ================= SOC cones ================= */
  QOCOInt soc = i - l;
  QOCOInt qi = q[soc];
  for (QOCOInt k = 0; k < qi; ++k) {
    z[soc_idx[soc] + k] =
        qoco_dot_dev(&W[Wsoc_idx[soc] + k * qi], &x[soc_idx[soc]], qi);
  }
}

__global__ void cone_product_kernel(const QOCOFloat* u, const QOCOFloat* v,
                                    QOCOFloat* p, QOCOInt l, QOCOInt nsoc,
                                    const QOCOInt* q, const QOCOInt* soc_idx)
{
  QOCOInt tid = blockIdx.x * blockDim.x + threadIdx.x;

  /* ================= LP cone ================= */
  if (tid < l) {
    p[tid] = u[tid] * v[tid];
    return;
  }

  /* ================= SOC cones ================= */
  QOCOInt soc_tid = tid - l;
  if (soc_tid >= nsoc)
    return;

  QOCOInt idx = soc_idx[soc_tid];
  /* one thread computes one SOC cone product */
  soc_product(&u[idx], &v[idx], &p[idx], q[soc_tid]);
}

__global__ void cone_division_kernel(const QOCOFloat* lambda,
                                     const QOCOFloat* v, QOCOFloat* d,
                                     QOCOInt l, QOCOInt nsoc, const QOCOInt* q,
                                     const QOCOInt* soc_idx)
{
  QOCOInt tid = blockIdx.x * blockDim.x + threadIdx.x;

  /* ================= LP cone ================= */
  if (tid < l) {
    d[tid] = safe_div(v[tid], lambda[tid]);
    return;
  }

  /* ================= SOC cones ================= */
  QOCOInt soc_tid = tid - l;
  if (soc_tid >= nsoc)
    return;

  QOCOInt idx = soc_idx[soc_tid];
  /* one thread handles one SOC cone */
  soc_division(&lambda[idx], &v[idx], &d[idx], q[soc_tid]);
}

__global__ void add_e_kernel(QOCOFloat* x, QOCOFloat a, QOCOInt l, QOCOInt nsoc,
                             const QOCOInt* q)
{
  QOCOInt tid = blockIdx.x * blockDim.x + threadIdx.x;

  /* ================= LP cone ================= */
  if (tid < l) {
    x[tid] -= a;
    return;
  }

  /* ================= SOC cones ================= */
  QOCOInt soc_tid = tid - l;
  if (soc_tid >= nsoc)
    return;

  /* compute starting index of SOC cone soc_tid */
  QOCOInt idx = l;
  for (QOCOInt k = 0; k < soc_tid; ++k) {
    idx += q[k];
  }

  /* subtract a from the cone "scalar" entry */
  x[idx] -= a;
}

void set_Wfull_identity(QOCOVectorf* Wfull, QOCOInt Wnnzfull,
                        QOCOVectori* Wsoc_idx, QOCOProblemData* data)
{
  CUDA_CHECK(cudaGetLastError());
  QOCOFloat* W = get_data_vectorf(Wfull);

  const int threads = 256;
  const int blocks = (Wnnzfull + threads - 1) / threads;

  // kernel 1: zero + linear cone
  if (data->l > 0) {
    set_Wfull_linear<<<blocks, threads>>>(W, Wnnzfull, data->l);
    CUDA_CHECK(cudaGetLastError());
  }

  // kernel 2: SOC blocks
  const int blocks2 = data->nsoc;
  if (data->nsoc > 0) {
    set_Wfull_soc<<<blocks2, 256>>>(W, get_data_vectori(data->q),
                                    get_data_vectori(Wsoc_idx), data->nsoc,
                                    data->l);
    CUDA_CHECK(cudaGetLastError());
  }
}

QOCOFloat cone_residual(const QOCOFloat* d_u, QOCOInt l, QOCOInt nsoc,
                        const QOCOInt* q, QOCOInt* soc_idx)
{
  QOCOInt total_threads = l + nsoc;
  if (total_threads == 0)
    return -1e7;

  QOCOInt block = 256;
  QOCOInt grid = (total_threads + block - 1) / block;

  QOCOFloat* d_block = nullptr;
  QOCOFloat* d_out = nullptr;
  QOCOFloat h_out = -1e7;

  CUDA_CHECK(cudaMalloc(&d_block, grid * sizeof(QOCOFloat)));
  CUDA_CHECK(cudaMalloc(&d_out, sizeof(QOCOFloat)));

  // -------- stage 1 --------
  cone_residual_stage1<<<grid, block, block * sizeof(QOCOFloat)>>>(
      d_u, l, nsoc, q, soc_idx, d_block);

  CUDA_CHECK(cudaGetLastError());

  // -------- stage 2 --------
  QOCOInt block2 = 1;
  while (block2 < grid)
    block2 <<= 1;
  block2 = min(block2, 1024);

  cone_residual_stage2<<<1, block2, block2 * sizeof(QOCOFloat)>>>(d_block,
                                                                  d_out, grid);

  CUDA_CHECK(cudaGetLastError());

  CUDA_CHECK(
      cudaMemcpy(&h_out, d_out, sizeof(QOCOFloat), cudaMemcpyDeviceToHost));

  CUDA_CHECK(cudaFree(d_block));
  CUDA_CHECK(cudaFree(d_out));

  return h_out;
}

void cone_product(const QOCOFloat* u, const QOCOFloat* v, QOCOFloat* p,
                  QOCOInt l, QOCOInt nsoc, const QOCOInt* q,
                  const QOCOInt* soc_idx)
{
  QOCOInt total_threads = l + nsoc;
  QOCOInt block = 256;
  QOCOInt grid = (total_threads + block - 1) / block;
  if (l > 0 || nsoc > 0) {
    cone_product_kernel<<<grid, block>>>(u, v, p, l, nsoc, q, soc_idx);
    CUDA_CHECK(cudaGetLastError());
  }
}

void cone_division(const QOCOFloat* lambda, const QOCOFloat* v, QOCOFloat* d,
                   QOCOInt l, QOCOInt nsoc, const QOCOInt* q,
                   const QOCOInt* soc_idx)
{
  QOCOInt total_threads = l + nsoc;
  QOCOInt block = 256;
  QOCOInt grid = (total_threads + block - 1) / block;
  if (l > 0 || nsoc > 0) {
    cone_division_kernel<<<grid, block>>>(lambda, v, d, l, nsoc, q, soc_idx);
    CUDA_CHECK(cudaGetLastError());
  }
}

void bring2cone(QOCOFloat* u, QOCOInt* soc_idx, QOCOProblemData* data)
{
  CUDA_CHECK(cudaGetLastError());
  QOCOFloat res =
      cone_residual(u, data->l, data->nsoc, get_data_vectori(data->q), soc_idx);
  if (res >= 0) {
    bring2cone_kernel<<<1, 1>>>(u, get_data_vectori(data->q), data->l,
                                data->nsoc);
    CUDA_CHECK(cudaGetLastError());
  }
}

void nt_multiply(QOCOFloat* W, QOCOInt* Wsoc_idx, QOCOInt* soc_idx,
                 QOCOFloat* x, QOCOFloat* z, QOCOInt l, QOCOInt m, QOCOInt nsoc,
                 QOCOInt* q)
{
  int threads = 256;
  int blocks = (l + nsoc + threads - 1) / threads;
  if (m > 0) {
    nt_multiply_kernel<<<blocks, threads>>>(W, Wsoc_idx, soc_idx, x, z, l, m,
                                            nsoc, q);
  }
  CUDA_CHECK(cudaGetLastError());
}

void compute_nt_scaling(QOCOWorkspace* work)
{
  QOCOFloat* W = get_data_vectorf(work->W);
  QOCOFloat* WtW = get_data_vectorf(work->WtW);
  QOCOFloat* Wfull = get_data_vectorf(work->Wfull);
  QOCOFloat* Winv = get_data_vectorf(work->Winv);
  QOCOFloat* Winvfull = get_data_vectorf(work->Winvfull);
  QOCOInt* Wsoc_idx = get_data_vectori(work->Wsoc_idx);
  QOCOInt* soc_idx = get_data_vectori(work->soc_idx);
  QOCOFloat* s = get_data_vectorf(work->s);
  QOCOFloat* z = get_data_vectorf(work->z);
  QOCOFloat* sbar = get_data_vectorf(work->sbar);
  QOCOFloat* zbar = get_data_vectorf(work->zbar);
  QOCOFloat* lambda = get_data_vectorf(work->lambda);
  QOCOInt* q = get_data_vectori(work->data->q);
  QOCOInt l = work->data->l;
  QOCOInt nsoc = work->data->nsoc;

  QOCOInt total_threads = l + nsoc;
  QOCOInt block = 128; // SOC threads are heavy; don't oversubscribe
  QOCOInt grid = (total_threads + block - 1) / block;

  if (work->data->m > 0) {
    compute_nt_scaling_kernel<<<grid, block>>>(W, WtW, Wfull, Winv, Winvfull, s,
                                               z, sbar, zbar, l, nsoc, q);
  }
  CUDA_CHECK(cudaGetLastError());

  /* ================= lambda = W * z ================= */
  nt_multiply(Wfull, Wsoc_idx, soc_idx, z, lambda, work->data->l, work->data->m,
              work->data->nsoc, q);
}

void compute_centering(QOCOSolver* solver)
{

  QOCOWorkspace* work = solver->work;
  QOCOFloat* xyz = get_data_vectorf(work->xyz);
  QOCOFloat* Ds = get_data_vectorf(work->Ds);
  QOCOFloat* ubuff1 = get_data_vectorf(work->ubuff1);
  QOCOFloat* ubuff2 = get_data_vectorf(work->ubuff2);
  QOCOFloat* Dzaff = &xyz[work->data->n + work->data->p];
  QOCOFloat a =
      qoco_min(linesearch(get_data_vectorf(work->z), Dzaff, 1.0, solver),
               linesearch(get_data_vectorf(work->s), Ds, 1.0, solver));

  // Compute rho. rho = ((s + a * Ds)'*(z + a * Dz)) / (s'*z).
  qoco_axpy(Dzaff, get_data_vectorf(work->z), ubuff1, a, work->data->m);
  qoco_axpy(Ds, get_data_vectorf(work->s), ubuff2, a, work->data->m);
  QOCOFloat rho = qoco_dot(ubuff1, ubuff2, work->data->m) /
                  qoco_dot(get_data_vectorf(work->z), get_data_vectorf(work->s),
                           work->data->m);

  // Compute sigma. sigma = max(0, min(1, rho))^3.
  QOCOFloat sigma = qoco_min(1.0, rho);
  sigma = qoco_max(0.0, sigma);
  work->sigma = sigma * sigma * sigma;
}

/**
 * @brief Compute maximum step length alpha >= 0 such that
 * x + alpha * dx remains in the second-order cone.
 */
__device__ QOCOFloat soc_step_length_dev(const QOCOFloat* x,
                                         const QOCOFloat* dx, QOCOInt n,
                                         QOCOFloat alpha_max)
{
  const QOCOFloat two = 2.0;
  const QOCOFloat four = 4.0;

  QOCOFloat alpha = alpha_max;

  // ----------------------------------
  // Scalar safeguard: x0 + alpha dx0 >= 0
  // ----------------------------------
  if (x[0] >= 0.0 && dx[0] < 0.0) {
    QOCOFloat a = -x[0] / dx[0];
    if (a < alpha)
      alpha = a;
  }

  // ----------------------------------
  // Compute quadratic coefficients
  // ----------------------------------

  // a = dx0^2 - ||dx1||^2
  QOCOFloat dx1_norm2 = 0.0;
  for (QOCOInt i = 1; i < n; ++i)
    dx1_norm2 += dx[i] * dx[i];
  QOCOFloat a = dx[0] * dx[0] - dx1_norm2;

  // b = 2*(x0*dx0 - x1^T dx1)
  QOCOFloat x1dx1 = 0.0;
  for (QOCOInt i = 1; i < n; ++i)
    x1dx1 += x[i] * dx[i];
  QOCOFloat b = two * (x[0] * dx[0] - x1dx1);

  // c = x0^2 - ||x1||^2
  QOCOFloat x1_norm2 = 0.0;
  for (QOCOInt i = 1; i < n; ++i)
    x1_norm2 += x[i] * x[i];
  QOCOFloat c = x[0] * x[0] - x1_norm2;

  if (c < 0.0)
    c = 0.0; // numerical safeguard

  // ----------------------------------
  // Discriminant
  // ----------------------------------
  QOCOFloat d = b * b - four * a * c;

  // ----------------------------------
  // Case analysis (same as Clarabel)
  // ----------------------------------

  // No positive root → no restriction
  if ((a > 0.0 && b > 0.0) || d < 0.0)
    return alpha;

  // Linear case
  if (qoco_abs(a) < 1e-14)
    return alpha;

  // Boundary case
  if (c == 0.0) {
    if (a >= 0.0)
      return alpha;
    else
      return 0.0;
  }

  // ----------------------------------
  // Stable quadratic root computation
  // ----------------------------------
  QOCOFloat sqrt_d = qoco_sqrt(d);

  QOCOFloat t;
  if (b >= 0.0)
    t = -b - sqrt_d;
  else
    t = -b + sqrt_d;

  QOCOFloat r1 = (two * c) / t;
  QOCOFloat r2 = t / (two * a);

  // Keep only positive roots
  if (r1 < 0.0)
    r1 = QOCOFloat_MAX;
  if (r2 < 0.0)
    r2 = QOCOFloat_MAX;

  QOCOFloat r = qoco_min(r1, r2);

  if (r < alpha)
    alpha = r;

  return alpha;
}

/**
 * @brief Parallel min reduction kernel: computes min(-x[i]/dx[i]) for dx[i] < 0
 * over the LP cone. Each block writes its local minimum to block_out.
 */
__global__ void lp_step_length_kernel(const QOCOFloat* x, const QOCOFloat* dx,
                                      QOCOInt n, QOCOFloat* block_out)
{
  extern __shared__ QOCOFloat sdata[];

  QOCOInt tid = threadIdx.x;
  QOCOInt gid = blockIdx.x * blockDim.x + tid;

  QOCOFloat val = QOCOFloat_MAX;
  if (gid < n && dx[gid] < 0.0)
    val = -x[gid] / dx[gid];

  sdata[tid] = val;
  __syncthreads();

  for (QOCOInt s = blockDim.x >> 1; s > 0; s >>= 1) {
    if (tid < s && sdata[tid + s] < sdata[tid])
      sdata[tid] = sdata[tid + s];
    __syncthreads();
  }

  if (tid == 0)
    block_out[blockIdx.x] = sdata[0];
}

/**
 * @brief Parallel kernel: one thread per SOC cone computes the closed-form step
 * length, then a shared-memory min-reduction writes each block's minimum to
 * block_out. Launch with blockDim.x == 1024.
 */
__global__ void soc_step_length_kernel(const QOCOFloat* u, const QOCOFloat* Du,
                                       const QOCOInt* q, const QOCOInt* soc_idx,
                                       QOCOInt nsoc, QOCOFloat alpha_lp,
                                       QOCOFloat* block_out)
{
  extern __shared__ QOCOFloat sdata[];

  QOCOInt tid = threadIdx.x;
  QOCOInt gid = blockIdx.x * blockDim.x + tid;

  QOCOFloat val = QOCOFloat_MAX;
  if (gid < nsoc)
    val = soc_step_length_dev(&u[soc_idx[gid]], &Du[soc_idx[gid]], q[gid],
                              alpha_lp);

  sdata[tid] = val;
  __syncthreads();

  for (QOCOInt s = blockDim.x >> 1; s > 0; s >>= 1) {
    if (tid < s && sdata[tid + s] < sdata[tid])
      sdata[tid] = sdata[tid + s];
    __syncthreads();
  }

  if (tid == 0)
    block_out[blockIdx.x] = sdata[0];
}

QOCOFloat linesearch(QOCOFloat* u, QOCOFloat* Du, QOCOFloat f,
                     QOCOSolver* solver)
{
  QOCOWorkspace* work = solver->work;
  QOCOProblemData* data = work->data;

  QOCOFloat alpha = 1.0;

  // ---------------------------
  // LP cone
  // ---------------------------
  if (data->l > 0) {
    int threads = 1024;
    int blocks = (data->l + threads - 1) / threads;

    QOCOFloat* d_block;
    CUDA_CHECK(cudaMalloc(&d_block, blocks * sizeof(QOCOFloat)));

    lp_step_length_kernel<<<blocks, threads, threads * sizeof(QOCOFloat)>>>(
        u, Du, data->l, d_block);
    CUDA_CHECK(cudaGetLastError());

    // Final reduction over blocks on host
    QOCOFloat* h_block = (QOCOFloat*)malloc(blocks * sizeof(QOCOFloat));
    CUDA_CHECK(cudaMemcpy(h_block, d_block, blocks * sizeof(QOCOFloat),
                          cudaMemcpyDeviceToHost));

    for (int i = 0; i < blocks; ++i) {
      if (h_block[i] < alpha)
        alpha = h_block[i];
    }

    free(h_block);
    CUDA_CHECK(cudaFree(d_block));
  }

  // ---------------------------
  // SOC cones
  // ---------------------------
  if (data->nsoc > 0) {
    int threads = 1024;
    int blocks = (data->nsoc + threads - 1) / threads;

    QOCOFloat* d_block;
    CUDA_CHECK(cudaMalloc(&d_block, blocks * sizeof(QOCOFloat)));

    soc_step_length_kernel<<<blocks, threads, threads * sizeof(QOCOFloat)>>>(
        u, Du, get_data_vectori(data->q), get_data_vectori(work->soc_idx),
        data->nsoc, alpha, d_block);
    CUDA_CHECK(cudaGetLastError());

    // Final reduction over blocks on host.
    QOCOFloat* h_block = (QOCOFloat*)malloc(blocks * sizeof(QOCOFloat));
    CUDA_CHECK(cudaMemcpy(h_block, d_block, blocks * sizeof(QOCOFloat),
                          cudaMemcpyDeviceToHost));

    for (int i = 0; i < blocks; ++i) {
      if (h_block[i] < alpha)
        alpha = h_block[i];
    }

    free(h_block);
    CUDA_CHECK(cudaFree(d_block));
  }

  // Safeguard against step-sizes which are too small.
  if (alpha < 1e-12) {
    return 0;
  }

  return f * alpha;
}

void add_e(QOCOFloat* x, QOCOFloat a, QOCOInt l, QOCOInt nsoc, QOCOVectori* q)
{
  QOCOInt total_threads = l + nsoc;
  QOCOInt block = 256;
  QOCOInt grid = (total_threads + block - 1) / block;

  if (l > 0 || nsoc > 0) {
    add_e_kernel<<<grid, block>>>(x, a, l, nsoc, get_data_vectori(q));
    CUDA_CHECK(cudaGetLastError());
  }
}
